---
layout: home

hero:
  name: Android 通知图标适配计划
  tagline: 为不符合 Android 原生通知设计的应用与厂商系统提供规范的单色图标资源
  actions:
    - theme: brand
      text: 立即开始
      link: /zh-cn/guide/home
    - theme: alt
      text: 参与贡献
      link: /zh-cn/contribute/submit

features:
  - icon: 📱
    title: 第三方应用
    details: 为 Android 第三方应用维护单色通知图标资源。
    link: /zh-cn/guide/icon-resources
    linkText: 浏览应用图标
  - icon: ⚙️
    title: 系统
    details: 为 Android 系统应用维护通用及厂商专属资源。
    link: /zh-cn/guide/icon-resources?category=system/common
    linkText: 浏览系统图标
  - icon: 🤝
    title: 社区维护
    details: 请求适配尚未收录的图标，或贡献通知图标资源。
    link: /zh-cn/contribute/request
    linkText: 请求适配
---