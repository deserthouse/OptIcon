# 介绍

> 这是一个 Android 通知图标适配计划，为不符合 Android 原生通知设计的应用与厂商系统提供规范的单色图标资源。

## 背景

这个项目设立的初衷是为了规范混乱的第三方应用生态，让第三方应用的通知图标也能按照原生 Android 通知图标的规范进行设计。

这一切的原因归根结底其实是当初 MIUI 不规范的小米推送通知图标导致的生态割裂问题，其他厂商也没有完全解决这个问题，而是普遍采用了 Apple 方案使用应用的桌面图标作为主要通知图标这种欺骗意义上的 “解决方案”，或者是 vivo 采用的自己维护一套单色通知图标的方案，但是在后来的 OriginOS 中也逐步放弃了。

作为这个项目的负责人，我的观点是，这个问题的责任在 Google，Android 明确规定了通知图标的设计规范，但 Google 并没有对厂商进行强制约束，导致厂商可以随意破坏原生通知图标的设计规范。

最后甚是可笑的是，Google 也在 Android 16 放弃了强制着色通知图标的设计规范，并在通知面板中将通知图标设置成了应用的桌面图标，完成了对生态的全面妥协。

这个从 2022 年开始启动的项目原名叫 **AndroidNotifyIconAdapt**，当年这个四不像的名字也一度导致项目空有资源但没有规范，现在它正式更名为 **Android Notification Icon Project** (代号为 **ANIP**)，并对原始的图标资源规则进行了全面改版，项目后期将全面投入更现代的持续社区维护中。

项目已由原 **AGPL-3.0** 许可协议调整至 **Apache-2.0**，ANIP 将以当前协议继续对外开放，任何人都可以在遵守协议的前提下使用、修改、分发本项目的资源，协议的变更不自动适用于之前的版本。

## 用途

ANIP 目前采用社区配套的 Xposed 模块方案对系统界面 (System UI) 进行适配，并提供了依赖社区维护的第三方应用、游戏、系统应用的单色通知图标资源与规则。

目前 ANIP 的支持路线如下，后期我们会将这些 Xposed 模块整合为一个聚合型模块统一进行适配并由 [BetterAndroid](https://github.com/BetterAndroid) 组织管理。

1. 可直接使用的 Xposed 模块

- HyperOS/MIUI 系统请参阅 [MIUI 原生通知图标](https://github.com/fankes/MIUINativeNotifyIcon)
- ColorOS、Realme UI、OxygenOS (≥12) 系统请参阅 [ColorOS 通知图标增强](https://github.com/fankes/ColorOSNotifyIcon)

2. 社区提出的适配需求

- 类原生、Pixel 用户请参阅 [此 Issue](repo://issues/102)
- Flyme 用户请参阅 [此 Issue](repo://issues/201)
- OneUI 用户请参阅 [此 Issue](repo://issues/475)

ANIP 提供了图标资源下载与应用的 [官方 SDK](../sdk/quick-start.md)，你可以使用这套 SDK 构建自己的 Xposed 模块或通知适配方案。

如果你是用户，你可以下载并体验 [ANIP 演示](branch://sdk/samples/demo/release)。

## 不规范公示

| 系统                 | 版本            | 破坏方式                                 |
| -------------------- | --------------- | ---------------------------------------- |
| 原生 Android         | ≥ 16            | 通知中心替换为应用图标                   |
| EMUI                 | 4.0、4.0.1、4.1 | 全部替换为应用图标                       |
| HarmonyOS            | ≥ 4.0           | 全部替换为应用图标                       |
| ColorOS<br/>OxygenOS | ≥ 15.0.1        | 全部替换为应用图标                       |
| RealmeUI             | ≥ 6.0           | 全部替换为应用图标                       |
| MIUI                 | ≤ 9、≥ 12.5     | 全部替换为应用图标                       |
| HyperOS              | 全部            | 系统应用白名单、第三方应用替换为应用图标 |
| OneUI                | ≥ 6.0           | 通知中心替换为应用图标 (可关闭)          |
| ZUI                  | 全部            | 全部替换为应用图标                       |
| Nubia UI             | 全部            | 全部替换为应用图标                       |
| RedMagicOS           | 全部            | 全部替换为应用图标                       |
| 360 OS               | 全部            | 全部替换为应用图标                       |
| CoolOS               | 全部            | 全部替换为应用图标                       |
| WaterOS              | 全部            | 全部替换为应用图标                       |
| Flyme                | 全部            | 系统与第三方应用白名单                   |
| OriginOS             | ≥ 6             | 全部替换为应用图标                       |

## 功能贡献

本项目的维护离不开各位开发者的支持和贡献，如果可能，欢迎提交 PR 为此项目贡献你认为需要的功能或前往 [GitHub Issues](repo://issues) 向我们提出建议。 